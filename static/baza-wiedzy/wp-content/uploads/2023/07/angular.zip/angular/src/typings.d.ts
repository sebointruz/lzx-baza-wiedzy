/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
declare module 'quill';
declare module 'leaflet';
declare module 'screenfull';
declare module 'd3-shape';
